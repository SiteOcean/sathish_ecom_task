/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./src/pages/_app.js":
/*!***************************!*\
  !*** ./src/pages/_app.js ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ App)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _store_contextData__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/store/contextData */ \"./src/store/contextData.js\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/styles/globals.css */ \"./src/styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nfunction App({ Component, pageProps }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_store_contextData__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n            ...pageProps\n        }, void 0, false, {\n            fileName: \"E:\\\\interViewTask\\\\ecom_task\\\\src\\\\pages\\\\_app.js\",\n            lineNumber: 5,\n            columnNumber: 28\n        }, this)\n    }, void 0, false, {\n        fileName: \"E:\\\\interViewTask\\\\ecom_task\\\\src\\\\pages\\\\_app.js\",\n        lineNumber: 5,\n        columnNumber: 10\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvcGFnZXMvX2FwcC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQW1EO0FBQ3JCO0FBRWYsU0FBU0MsSUFBSSxFQUFFQyxTQUFTLEVBQUVDLFNBQVMsRUFBRTtJQUNsRCxxQkFBTyw4REFBQ0gsMERBQWdCQTtrQkFBQyw0RUFBQ0U7WUFBVyxHQUFHQyxTQUFTOzs7Ozs7Ozs7OztBQUNuRCIsInNvdXJjZXMiOlsiRTpcXGludGVyVmlld1Rhc2tcXGVjb21fdGFza1xcc3JjXFxwYWdlc1xcX2FwcC5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgQ29udGV4dENvbXBvbmVudCBmcm9tIFwiQC9zdG9yZS9jb250ZXh0RGF0YVwiO1xuaW1wb3J0IFwiQC9zdHlsZXMvZ2xvYmFscy5jc3NcIjtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQXBwKHsgQ29tcG9uZW50LCBwYWdlUHJvcHMgfSkge1xuICByZXR1cm4gPENvbnRleHRDb21wb25lbnQ+PENvbXBvbmVudCB7Li4ucGFnZVByb3BzfSAvPjwvQ29udGV4dENvbXBvbmVudD47XG59XG4iXSwibmFtZXMiOlsiQ29udGV4dENvbXBvbmVudCIsIkFwcCIsIkNvbXBvbmVudCIsInBhZ2VQcm9wcyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/pages/_app.js\n");

/***/ }),

/***/ "./src/store/contextData.js":
/*!**********************************!*\
  !*** ./src/store/contextData.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__),\n/* harmony export */   getContextData: () => (/* binding */ getContextData)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n\nconst { createContext, useState, useContext } = __webpack_require__(/*! react */ \"react\");\nconst EcomComtext = createContext();\nconst ContextComponent = ({ children })=>{\n    const [cartData, setCartData] = useState([]);\n    const [order, setOrder] = useState(null);\n    const addToCart = (pro)=>{\n        let obj = {\n            ...pro,\n            quantity: 1\n        };\n        setCartData((prev)=>[\n                ...prev,\n                obj\n            ]);\n    };\n    const increaseQuantity = (id)=>{\n        setCartData((prev)=>prev.map((val)=>{\n                if (val.id === id) {\n                    return {\n                        ...val,\n                        quantity: val.quantity + 1\n                    };\n                }\n                return val;\n            }));\n    };\n    const decreaseQuantity = (id)=>{\n        setCartData((prev)=>prev.map((val)=>{\n                if (val.id === id) {\n                    return {\n                        ...val,\n                        quantity: val.quantity > 1 ? val.quantity - 1 : 1\n                    };\n                }\n                return val;\n            }));\n    };\n    const removeFromCart = (id)=>{\n        setCartData((prev)=>prev.filter((product)=>product.id !== id));\n    };\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(EcomComtext.Provider, {\n        value: {\n            cartData,\n            addToCart,\n            order,\n            setOrder,\n            increaseQuantity,\n            decreaseQuantity,\n            removeFromCart\n        },\n        children: children\n    }, void 0, false, {\n        fileName: \"E:\\\\interViewTask\\\\ecom_task\\\\src\\\\store\\\\contextData.js\",\n        lineNumber: 41,\n        columnNumber: 5\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ContextComponent);\nconst getContextData = ()=>{\n    return useContext(EcomComtext);\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvc3RvcmUvY29udGV4dERhdGEuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQSxNQUFNLEVBQUVBLGFBQWEsRUFBRUMsUUFBUSxFQUFFQyxVQUFVLEVBQUUsR0FBR0MsbUJBQU9BLENBQUMsb0JBQU87QUFFL0QsTUFBTUMsY0FBY0o7QUFFcEIsTUFBTUssbUJBQW1CLENBQUMsRUFBRUMsUUFBUSxFQUFFO0lBQ3BDLE1BQU0sQ0FBQ0MsVUFBVUMsWUFBWSxHQUFHUCxTQUFTLEVBQUU7SUFDM0MsTUFBTSxDQUFDUSxPQUFPQyxTQUFTLEdBQUdULFNBQVM7SUFFbkMsTUFBTVUsWUFBWSxDQUFDQztRQUNqQixJQUFJQyxNQUFNO1lBQUUsR0FBR0QsR0FBRztZQUFFRSxVQUFVO1FBQUU7UUFDaENOLFlBQVksQ0FBQ08sT0FBUzttQkFBSUE7Z0JBQU1GO2FBQUk7SUFDdEM7SUFFQSxNQUFNRyxtQkFBbUIsQ0FBQ0M7UUFDeEJULFlBQVksQ0FBQ08sT0FDWEEsS0FBS0csR0FBRyxDQUFDLENBQUNDO2dCQUNSLElBQUlBLElBQUlGLEVBQUUsS0FBS0EsSUFBSTtvQkFDakIsT0FBTzt3QkFBRSxHQUFHRSxHQUFHO3dCQUFFTCxVQUFVSyxJQUFJTCxRQUFRLEdBQUc7b0JBQUU7Z0JBQzlDO2dCQUNBLE9BQU9LO1lBQ1Q7SUFFSjtJQUVBLE1BQU1DLG1CQUFtQixDQUFDSDtRQUN4QlQsWUFBWSxDQUFDTyxPQUNYQSxLQUFLRyxHQUFHLENBQUMsQ0FBQ0M7Z0JBQ1IsSUFBSUEsSUFBSUYsRUFBRSxLQUFLQSxJQUFJO29CQUNqQixPQUFPO3dCQUFFLEdBQUdFLEdBQUc7d0JBQUVMLFVBQVVLLElBQUlMLFFBQVEsR0FBRyxJQUFJSyxJQUFJTCxRQUFRLEdBQUcsSUFBSTtvQkFBRTtnQkFDckU7Z0JBQ0EsT0FBT0s7WUFDVDtJQUVKO0lBRUEsTUFBTUUsaUJBQWlCLENBQUNKO1FBQ3RCVCxZQUFZLENBQUNPLE9BQVNBLEtBQUtPLE1BQU0sQ0FBQyxDQUFDQyxVQUFZQSxRQUFRTixFQUFFLEtBQUtBO0lBQ2hFO0lBRUEscUJBQ0UsOERBQUNiLFlBQVlvQixRQUFRO1FBQ25CQyxPQUFPO1lBQ0xsQjtZQUNBSTtZQUNBRjtZQUNBQztZQUNBTTtZQUNBSTtZQUNBQztRQUNGO2tCQUVDZjs7Ozs7O0FBR1A7QUFFQSxpRUFBZUQsZ0JBQWdCQSxFQUFDO0FBRXpCLE1BQU1xQixpQkFBaUI7SUFDNUIsT0FBT3hCLFdBQVdFO0FBQ3BCLEVBQUUiLCJzb3VyY2VzIjpbIkU6XFxpbnRlclZpZXdUYXNrXFxlY29tX3Rhc2tcXHNyY1xcc3RvcmVcXGNvbnRleHREYXRhLmpzIl0sInNvdXJjZXNDb250ZW50IjpbImNvbnN0IHsgY3JlYXRlQ29udGV4dCwgdXNlU3RhdGUsIHVzZUNvbnRleHQgfSA9IHJlcXVpcmUoXCJyZWFjdFwiKTtcclxuXHJcbmNvbnN0IEVjb21Db210ZXh0ID0gY3JlYXRlQ29udGV4dCgpO1xyXG5cclxuY29uc3QgQ29udGV4dENvbXBvbmVudCA9ICh7IGNoaWxkcmVuIH0pID0+IHtcclxuICBjb25zdCBbY2FydERhdGEsIHNldENhcnREYXRhXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbb3JkZXIsIHNldE9yZGVyXSA9IHVzZVN0YXRlKG51bGwpO1xyXG5cclxuICBjb25zdCBhZGRUb0NhcnQgPSAocHJvKSA9PiB7XHJcbiAgICBsZXQgb2JqID0geyAuLi5wcm8sIHF1YW50aXR5OiAxIH07XHJcbiAgICBzZXRDYXJ0RGF0YSgocHJldikgPT4gWy4uLnByZXYsIG9ial0pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGluY3JlYXNlUXVhbnRpdHkgPSAoaWQpID0+IHtcclxuICAgIHNldENhcnREYXRhKChwcmV2KSA9PlxyXG4gICAgICBwcmV2Lm1hcCgodmFsKSA9PiB7XHJcbiAgICAgICAgaWYgKHZhbC5pZCA9PT0gaWQpIHtcclxuICAgICAgICAgIHJldHVybiB7IC4uLnZhbCwgcXVhbnRpdHk6IHZhbC5xdWFudGl0eSArIDEgfTsgXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB2YWw7IFxyXG4gICAgICB9KVxyXG4gICAgKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBkZWNyZWFzZVF1YW50aXR5ID0gKGlkKSA9PiB7XHJcbiAgICBzZXRDYXJ0RGF0YSgocHJldikgPT5cclxuICAgICAgcHJldi5tYXAoKHZhbCkgPT4ge1xyXG4gICAgICAgIGlmICh2YWwuaWQgPT09IGlkKSB7XHJcbiAgICAgICAgICByZXR1cm4geyAuLi52YWwsIHF1YW50aXR5OiB2YWwucXVhbnRpdHkgPiAxID8gdmFsLnF1YW50aXR5IC0gMSA6IDEgfTsgXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB2YWw7XHJcbiAgICAgIH0pXHJcbiAgICApO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHJlbW92ZUZyb21DYXJ0ID0gKGlkKSA9PiB7XHJcbiAgICBzZXRDYXJ0RGF0YSgocHJldikgPT4gcHJldi5maWx0ZXIoKHByb2R1Y3QpID0+IHByb2R1Y3QuaWQgIT09IGlkKSk7XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxFY29tQ29tdGV4dC5Qcm92aWRlclxyXG4gICAgICB2YWx1ZT17e1xyXG4gICAgICAgIGNhcnREYXRhLFxyXG4gICAgICAgIGFkZFRvQ2FydCxcclxuICAgICAgICBvcmRlcixcclxuICAgICAgICBzZXRPcmRlcixcclxuICAgICAgICBpbmNyZWFzZVF1YW50aXR5LFxyXG4gICAgICAgIGRlY3JlYXNlUXVhbnRpdHksXHJcbiAgICAgICAgcmVtb3ZlRnJvbUNhcnRcclxuICAgICAgfX1cclxuICAgID5cclxuICAgICAge2NoaWxkcmVufVxyXG4gICAgPC9FY29tQ29tdGV4dC5Qcm92aWRlcj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgQ29udGV4dENvbXBvbmVudDtcclxuXHJcbmV4cG9ydCBjb25zdCBnZXRDb250ZXh0RGF0YSA9ICgpID0+IHtcclxuICByZXR1cm4gdXNlQ29udGV4dChFY29tQ29tdGV4dCk7XHJcbn07XHJcbiJdLCJuYW1lcyI6WyJjcmVhdGVDb250ZXh0IiwidXNlU3RhdGUiLCJ1c2VDb250ZXh0IiwicmVxdWlyZSIsIkVjb21Db210ZXh0IiwiQ29udGV4dENvbXBvbmVudCIsImNoaWxkcmVuIiwiY2FydERhdGEiLCJzZXRDYXJ0RGF0YSIsIm9yZGVyIiwic2V0T3JkZXIiLCJhZGRUb0NhcnQiLCJwcm8iLCJvYmoiLCJxdWFudGl0eSIsInByZXYiLCJpbmNyZWFzZVF1YW50aXR5IiwiaWQiLCJtYXAiLCJ2YWwiLCJkZWNyZWFzZVF1YW50aXR5IiwicmVtb3ZlRnJvbUNhcnQiLCJmaWx0ZXIiLCJwcm9kdWN0IiwiUHJvdmlkZXIiLCJ2YWx1ZSIsImdldENvbnRleHREYXRhIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/store/contextData.js\n");

/***/ }),

/***/ "./src/styles/globals.css":
/*!********************************!*\
  !*** ./src/styles/globals.css ***!
  \********************************/
/***/ (() => {



/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./src/pages/_app.js"));
module.exports = __webpack_exports__;

})();