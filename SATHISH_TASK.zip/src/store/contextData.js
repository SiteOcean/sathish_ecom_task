const { createContext, useState, useContext } = require("react");

const EcomComtext = createContext()

const ContextComponent=({children})=>{

    const [cartData, setCartData] = useState([])
    const [order, setOrder] = useState(null)
    const addToCart=(pro)=>{
        setCartData((prev)=>[...prev, pro])
    }

    return <EcomComtext.Provider value={{cartData, addToCart, order, setOrder}}>
        {children}
    </EcomComtext.Provider>
}

export default ContextComponent;

export const getContextData = () =>{
    return useContext(EcomComtext)
}