import { useEffect, useState } from "react"
import { useRouter } from "next/router"
import Link from "next/link"
import { getContextData } from "@/store/contextData"
import ImageCarousel from "@/components/imageCarousel"
import Navbar from "@/components/navBar"

export default function CartPage() {

    const {cartData, addToCart} = getContextData()
    const router = useRouter();
  

    if(cartData.length === 0){
        return <div className="capitalize"><Navbar/>
       <div className="flex justify-center items-center min-h-[90vh]">no more Products in cart</div> </div>
    }
  return (
   <div>
    <Navbar/>
    <div className="container mx-auto px-4 py-8" >
      <h2 className="text-2xl font-bold mb-6">Product Listing</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {cartData.map((product) => (
          <div
            key={product.id}
            className="border rounded-lg shadow-sm hover:shadow-md transition-shadow p-4"
          >
            <ImageCarousel images={product.images}/>
            <h3 className="text-lg font-semibold">{product.title}</h3>
            <p className="text-gray-600 text-sm">{product.description}</p>
            <div className="mt-4 flex justify-between items-center">
              <span className="text-lg font-bold text-gray-800">${product.price}</span>
              <button onClick={()=>addToCart(product)} className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
                Add to Cart
              </button>
              <Link href={`/${product.title}?id=${product.id}`} className="bg-green-500 text-white px-4 py-2 rounded hover:bg-blue-600">
                View
              </Link>
            </div>
          </div>
        ))}
      </div>
    </div>
   </div>
  );
}
